"""Generate the fixed-size FastSAM ONNX from the supplied preferred checkpoint.

Reconstructed and executed by the InsertCreator maintainer on 11 November 2026.
This script is supplied under AGPL-3.0-or-later. Upstream files retain their
original licences and notices. Install the accompanying pinned environment and
Ultralytics source archive first; no automatic dependency install is enabled.
"""
from pathlib import Path
import hashlib
import os

os.environ.setdefault('YOLO_CONFIG_DIR', str(Path.cwd() / '.export-config'))
os.environ['YOLO_AUTOINSTALL'] = 'false'
os.environ['YOLO_OFFLINE'] = 'true'
os.environ.setdefault('MPLCONFIGDIR', str(Path.cwd() / '.export-config/matplotlib'))
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('MKL_NUM_THREADS', '2')

def export_model(checkpoint='FastSAM-s.pt'):
    from ultralytics import FastSAM, settings
    import torch
    settings.update({'sync':False})
    torch.set_num_threads(2)
    path = Path(checkpoint).resolve()
    if not path.is_file(): raise FileNotFoundError(path)
    # The original input is identified here for reproducibility. A user making
    # an intentional modified checkpoint may replace this expected digest.
    expected = 'c9f78716a81c7aff0d608ccc73e1b82ab3aaad86005049f6a92106a0be6d0844'
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError('Checkpoint digest differs; verify your intended modification before changing this check')
    model = FastSAM(str(path))
    return Path(model.export(format='onnx', imgsz=1024, batch=1, opset=17,
                             simplify=True, half=False, dynamic=False,
                             nms=False, device='cpu'))

if __name__ == '__main__':
    print(export_model())
