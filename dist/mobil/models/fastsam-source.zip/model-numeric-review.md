Packaging note: this historical audit report is reproduced as evidence. Its script/log and workspace references describe the original audit, not additional generation prerequisites. The raw strict result is supplied here as rebuild-verification.json; README.md and export.py give the standalone generation recipe.

# Independent numerical review of the reconstructed FastSAM export

11 November 2026. **The original strict numerical result remains FAIL. Technical source/graph correspondence is nevertheless supported within the explicit scope below. These are different conclusions.** No tolerance was increased and no failed output was omitted. The production ONNX remains unchanged.

The reviewer read the completed export recipe/result and independently loaded, checked and ran the original and rebuilt ONNX in the existing isolated environment. A second checkpoint export was not run by this reviewer. The executable review script, full statistics and log are `model-numeric-review.py`, `.json` and `.log` beside this file. No dependency was installed, no production source changed and no output was published.

## Preserved strict result and output channels

The unchanged comparison is `np.allclose(original, rebuilt, atol=1e-4, rtol=1e-4)`, with the rebuilt operand supplying the relative term, exactly as in the original check. Both operands are finite. The original `model-rebuild-result.json` retains `passed=false`; its SHA-256 before/after review is `b0b94b8edf09fbe0624cbbaf13922364135e594717afdee3ef276f9b13d9c4e4`.

| Synthetic input | Bbox channels 0:4: failing values / 86,016 | Score channel 4: failures / 21,504 | Mask coefficients 5:37: failures / 688,128 | Prototypes output1: failures / 2,097,152 |
| --- | --- | --- | --- | --- |
| Black | 0 | 0 | 0 | 0 |
| Seeded RGB | 0 | 0 | 0 | 0 |
| Separate geometric bars | **9: width 4, height 5** | 0 | 0 | 0 |

For geometric bars, the maximum bbox difference is **0.0140380859375 pixels**. That particular pair is `346.332763671875` versus `346.3187255859375`, whose tolerance is `0.03473187255859375`; it passes. It must not be confused with the actual failing values. The nine failures involve rebuilt widths/heights from **4.023353576660156 to 44.019893646240234**, not values near zero. The worst error/tolerance ratio is **1.7985611510791366**: height `31.23297119140625` versus `31.23876953125`, error `0.00579833984375`, tolerance `0.003223876953125`.

The score maximum error is **1.2516975402832031e-6**, and the mask-coefficient maximum is **9.012222290039062e-5**; both groups pass the original tolerance element by element. Output1's maximum error is **0.0001361370086669922**, with maximum error/tolerance ratio **0.7211702518588313**, so it also passes the combined absolute/relative criterion. A maximum above the absolute term alone is not necessarily a combined-tolerance failure. No sign changes occur in these groups for this control.

There is a separate near-zero **confidence** observation: the nine failing box values belong to eight anchors whose scores in both models are between zero and **1.4901161193847656e-6**. None survives the tested application candidate thresholds of 0.05 or 0.25. At those thresholds, both models select the same 25 and 12 pre-NMS anchors respectively, with zero threshold crossings and zero strict bbox failures in those candidate sets. Their maximum bbox differences are `0.000244140625` and `0.0001220703125` pixels. This is useful context for this input; **filtering does not retroactively pass the original raw-tensor control**. Black and seeded RGB have no candidates at either threshold, so those two controls do not demonstrate real-object recognition quality.

## Graph, parameters and a causal control

Independent ONNX checks confirm both models have **268 nodes**, identical node inputs/outputs, operators and attributes when only diagnostic node names/documentation are ignored; the same opset, IR and runtime input/output contracts; no local functions or sparse initializers. All **172 initializer names, shapes and dtypes** match and their values satisfy the original initializer tolerance `2e-6 + 2e-5 * abs(rebuilt)`.

There are **131 bit-different float initializer tensors**, all identified as Conv/BatchNorm-fused by the earlier checkpoint correspondence record. Other initializers are bit-identical, including fixed export constants. Across the changed tensors, **1,552,459 values differ in bits**: 1,177,543 by one ULP, 359,127 by two ULPs, and 15,789 by more than two ULPs. Do not describe every difference as one ULP. Cancellation in small fused bias values can yield a much larger ULP count: one bias tensor reaches 1,024 ULPs while its maximum absolute difference is only `1.1920928955078125e-7`. The largest absolute initializer difference remains `3.814697265625e-6`.

To isolate the cause without touching either file, the review copied the **original graph in memory and replaced only its initializers with the rebuilt initializers**. On the failing geometric-bars input, both resulting outputs are **bit-for-bit identical to the rebuilt model's outputs**. Repeating the original model on the same input also produces bit-identical outputs. Thus initializer differences are sufficient to reproduce the observed difference in this controlled run; hidden wiring/attribute differences and run-to-run variation are not needed to explain it.

This is consistent with small floating-point differences in Conv/BN fusion subsequently propagated through the same network. It does not identify the original uploader's CPU, operating system, kernel or exact arithmetic ordering. The same graph with different float parameters is also not literally the same exact mathematical function. The review does not erase that distinction by calling the rebuilt file identical.

## What can be concluded about the source

Together with the retained actual export execution, full checkpoint identity and prior independent checkpoint/fusion checks, the reproduced graph and parameter agreement supply strong, concrete evidence that the supplied preferred checkpoint and pinned model/export sources correspond to this distributed model. The result is materially stronger than the earlier filename/card/static-subset evidence. **A scoped technical source-correspondence gate can be supported while the stricter raw-output test remains failed.**

That support is for reconstruction of the model's computation structure and numerical parameters within the stated initializer tolerance. It is not a claim that the reconstructed build is byte-identical, passes all three strict inference controls, has universally equivalent outputs or is approved as a runtime replacement. This review does not by itself certify completeness of the final source archive, its grants/notices, source-offer placement or legal compliance; those remain the package/licensing review's job. Nor does it invent a universal requirement for a bit-identical rebuild.

Recommended release evidence wording:

> The supplied checkpoint/export sources were executed and reproduce the same ONNX computation structure, with Conv/BN-fused parameter differences within the recorded initializer tolerance. One of three strict raw-output controls fails on nine low-confidence bbox values; that failure is retained. The application continues to distribute the original reviewed ONNX.

## Limits and artifact integrity

This review used native ONNX Runtime **1.31.1 CPUExecutionProvider**, two intra-op threads, one inter-op thread and default graph optimizations. It is not verification of the application's browser WASM runtime. No real-photo corpus, NMS equality, reconstructed masks/contours, calibrated millimetre error, native phone or physical fit was tested here. Small coefficient/prototype differences can still matter near a later decision boundary; candidate-threshold agreement on three synthetic cases is not a general guarantee.

Original ONNX SHA-256: `8663b25472f06d36fc90f9b6262318292b760403c69c240360da5d1a3509f1ea`. Rebuilt SHA-256: `93cbaa9ca794073f31a319816a40b16584fae1708f50aa4334ec033578e37724`. Both were checked before and after the numerical review. Only this review's script/report/log were written. Neither the original strict report nor either ONNX was modified.
