# FastSAM-s Corresponding Source

Prepared 11 November 2026 for InsertCreator's unchanged runtime model:

- Runtime `fastsam_s.onnx`, 47,637,745 bytes; SHA-256
  `8663b25472f06d36fc90f9b6262318292b760403c69c240360da5d1a3509f1ea`.
- Preferred input `FastSAM-s.pt`, 23,851,578 bytes; SHA-256
  `c9f78716a81c7aff0d608ccc73e1b82ab3aaad86005049f6a92106a0be6d0844`.
- Complete Ultralytics 8.4.107 source archive; commit
  `efacaada0f20c5dc8d4fec6d2412f742a5233d21`. The annotated tag
  `2edf0de1441538f77af3f4f86c9e68eee5a852b4` points to that commit.
  Archive SHA-256 `d11ed1cf619a914708237c4c0bc5d98761b6da61b64ee3f495ab68f32e70a1b8`.

## Rights, credits and scope

The FastSAM model and the covered source materials are distributed under
GNU AGPL version 3; see `AGPL-3.0.txt` and the original source notices.
FastSAM authors: CASIA-LMC-Lab/CASIA-IVA-Lab FastSAM contributors.
Ultralytics code: Ultralytics and its contributors, with original notices in
the complete source archive. The original ONNX conversion was published by
anakhiu/fastsam-onnx, card revision 8bb24a5b8339d6494012e5a51b18bb34fbfef07d.
The original card/README are retained unchanged as provenance. Their Apache
assertions are not relied on as a permissive grant for this exact model.

The new export wrapper is supplied under AGPL-3.0-or-later. This wrapper grant
does not change any upstream work's own licence. Standard unmodified export
tools retain their own licences and are identified in the pinned environment.
This component notice does not grant a new licence over other independent
InsertCreator application code. Model use/output alone is not a declaration
that all independent application code or every generated shape is AGPL.

You may copy, modify and redistribute covered materials under the applicable
AGPL terms, including its corresponding-source and notice conditions. There
is no warranty, to the extent permitted by law; the complete licence controls.

## Rebuild, run and modify

Use a separate Python 3.12 environment on a Windows x86-64 CPU, the environment
validated for this recipe. These are ordinary source files; no key, password
or registration is needed. Other supported platforms may also work but were
not validated here. Use a short working directory on Windows, or invoke Python
with a supported extended-length path, if deeply nested upstream licence files
hit the Windows path-length limit. Do not omit those licence files.

Extract all archive members together. In an isolated virtual environment run:

    python -m pip install -r requirements-export.txt
    python -m pip install --no-deps ./ultralytics-v8.4.107.tar.gz
    python export.py

The second command installs the exact source archive supplied here, rather than
relying on an unrelated latest release. The export script was actually executed
for the recorded verification. It takes the supplied checkpoint and writes
`FastSAM-s.onnx` beside it: FP32, batch 1, 1024x1024, opset 17, fixed dimensions,
onnxslim simplification, CPU and no exported NMS. It disables automatic package
installation and sets local configuration paths. No training photos are needed
to regenerate this inference model from its preferred checkpoint.

Input: `images`, float32 [1,3,1024,1024], RGB divided by 255 with the application's
documented letterboxing. Outputs: float32 [1,37,21504] and [1,32,256,256]. The
separate browser application performs mask decoding and physical calibration.

To modify this model, change the checkpoint/configuration or supplied model
classes, then regenerate with the required interface. `CHECKPOINT-ARCHITECTURE.json`
records the actual checkpoint configuration; do not substitute a similarly
named generic model. The export script checks the original input hash; adjust
that check intentionally when using your own modified checkpoint. Add the
required modification/date notices when distributing modified covered work.
Loading a PyTorch checkpoint can execute its serialization code, so verify the
exact supplied input before loading it. The provided source is unrestricted by
an installation key; the hash check is editable source, not a permission gate.

## Actual validation and reproducibility

`rebuild-verification.json` records the executed exporter/environment, full model
checker, computation-node/attribute/wiring/opset/function/initializer and I/O
comparisons, plus native CPU inference on three deterministic synthetic RGB
inputs. No user photo was uploaded. Metadata/timestamps can change the output
file hash; byte-identical output is not promised. All 268 computation nodes and
all 172 initializer identities/values correspond under the stated source
comparison, which ignores diagnostic node names/docstrings only and separately
checks numerical initializer values within its recorded tolerance.

The original strict numeric result is deliberately preserved as `passed:false`:
one of the three synthetic controls has nine bounding-box width/height values
outside its selected allclose tolerance. All nine belong to eight low-confidence
anchors below both actual application confidence thresholds. Score and mask
coefficient channels pass that control. All 131 bit-different initializer tensors
are identified as Conv/BatchNorm fusion results; their maximum absolute change
is 0.000003814697265625. The exact original build host was not recovered.

`model-numeric-review.json` and `.md` retain the distribution, threshold and
causal checks. `source-correspondence-decision.json` records the separately
reviewed source conclusion under AGPL sections 1/6(d); it does not turn the failed
strict numeric test into a pass. The source recipe is supplied for the unchanged
original runtime model; the rebuilt ONNX is not installed into the application.
No universal numeric identity, improved model quality or every-device/physical
accuracy is claimed. AGPL does not impose a universal byte-identical build test.

`MANIFEST.json` identifies the included materials and their exact digests.
The full original source archive contains the architecture, class definitions,
generation code and notices. No extra private conversion shim was used.
Paths in the preserved review records identify the original audit workspace;
they are not extra generation dependencies. The self-contained generation
instructions above use only this archive's supplied inputs and versioned tools.

Original public source locations:
- https://github.com/ultralytics/assets/releases/download/v8.4.0/FastSAM-s.pt
- https://github.com/ultralytics/ultralytics/tree/efacaada0f20c5dc8d4fec6d2412f742a5233d21
- https://huggingface.co/anakhiu/fastsam-onnx/tree/8bb24a5b8339d6494012e5a51b18bb34fbfef07d
- https://github.com/CASIA-LMC-Lab/FastSAM
- https://pypi.org/ (versioned unmodified export-tool packages)

The operator supplies this complete model-source archive beside the runtime
model through the same website at no extra charge, preserving availability
as required by AGPL section 6(d). This archive contains no virtual environment,
account configuration, credentials, caches, logs or user photographs.
